# data_root = '/mnt/data2/deeplesion/dataset/'
data_root = '/home1/hli/datasets/DeepLesion/Images_png/'
