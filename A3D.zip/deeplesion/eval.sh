PYTHON=${PYTHON:-"python"}
python ./deeplesion/eval.py --config $1 --checkpoint $2