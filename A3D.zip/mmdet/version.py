# GENERATED VERSION FILE
# TIME: Tue Sep 28 14:27:47 2021

__version__ = '1.0rc1+c42460f'
short_version = '1.0rc1'
